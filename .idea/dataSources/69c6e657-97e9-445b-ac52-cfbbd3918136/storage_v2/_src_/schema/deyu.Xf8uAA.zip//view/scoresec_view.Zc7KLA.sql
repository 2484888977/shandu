create view scoresec_view as
select `deyu`.`scoresec`.`scoresecid`   AS `scoresecid`,
       `deyu`.`scoresec`.`scoresecinfo` AS `scoresecinfo`,
       `deyu`.`scoresec`.`scorefirid`   AS `scorefirid`,
       `deyu`.`scoresec`.`classid`      AS `classid`,
       `deyu`.`scoresec`.`score`        AS `score`,
       `deyu`.`scorefirst`.`scoreinfo`  AS `scoreinfo`,
       `deyu`.`scoreclass`.`classinfo`  AS `classinfo`
from ((`deyu`.`scorefirst` join `deyu`.`scoresec`)
         join `deyu`.`scoreclass`)
where ((`deyu`.`scoresec`.`scorefirid` = `deyu`.`scorefirst`.`scoreid`) and
       (`deyu`.`scoresec`.`classid` = `deyu`.`scoreclass`.`classid`));

