create view user_view as
select `deyu`.`user`.`username`           AS `username`,
       `deyu`.`user`.`u_id`               AS `u_id`,
       `deyu`.`user`.`password`           AS `password`,
       `deyu`.`user`.`u_mail`             AS `u_mail`,
       `deyu`.`user`.`u_name`             AS `u_name`,
       `deyu`.`user`.`u_sex`              AS `u_sex`,
       `deyu`.`user`.`u_add`              AS `u_add`,
       `deyu`.`user`.`jurisdiction`       AS `jurisdiction`,
       `deyu`.`user`.`u_class`            AS `u_class`,
       `deyu`.`user`.`stateCode`          AS `stateCode`,
       `deyu`.`user`.`info`               AS `info`,
       `deyu`.`user`.`user_id`            AS `user_id`,
       `deyu`.`user`.`address`            AS `address`,
       `deyu`.`user`.`qq`                 AS `qq`,
       `deyu`.`user`.`vx`                 AS `vx`,
       `deyu`.`userclass`.`userinfo`      AS `userinfo`,
       `deyu`.`qxinfo`.`jurisdictioninfo` AS `jurisdictioninfo`,
       `deyu`.`userstate`.`stateinfo`     AS `stateinfo`,
       `deyu`.`college`.`collegeinfo`     AS `collegeinfo`,
       `deyu`.`user`.`u_classinfo`        AS `u_classinfo`,
       `deyu`.`user`.`openid`             AS `openid`,
       `deyu`.`user`.`apartmentid`        AS `apartmentid`,
       `deyu`.`user`.`apartmentid2`       AS `apartmentid2`
from ((((`deyu`.`user` join `deyu`.`userclass`) join `deyu`.`qxinfo`) join `deyu`.`userstate`)
         join `deyu`.`college`)
where ((`deyu`.`user`.`u_class` = `deyu`.`userclass`.`userid`) and
       (`deyu`.`user`.`stateCode` = `deyu`.`userstate`.`stateid`) and
       (`deyu`.`user`.`jurisdiction` = `deyu`.`qxinfo`.`jurisdiction`) and
       (`deyu`.`user`.`u_classinfo` = `deyu`.`college`.`collegeid`));

