create view stu_view as
select `deyu`.`students`.`s_id`           AS `s_id`,
       `deyu`.`students`.`s_name`         AS `s_name`,
       `deyu`.`students`.`s_sex`          AS `s_sex`,
       `deyu`.`students`.`s_proid`        AS `s_proid`,
       `deyu`.`students`.`s_nation`       AS `s_nation`,
       `deyu`.`students`.`s_add`          AS `s_add`,
       `deyu`.`students`.`s_home`         AS `s_home`,
       `deyu`.`students`.`s_dadname`      AS `s_dadname`,
       `deyu`.`students`.`s_dadadd`       AS `s_dadadd`,
       `deyu`.`students`.`s_mumname`      AS `s_mumname`,
       `deyu`.`students`.`s_mumadd`       AS `s_mumadd`,
       `deyu`.`students`.`s_class`        AS `s_class`,
       `deyu`.`students`.`s_room`         AS `s_room`,
       `deyu`.`classes`.`classes`         AS `classes`,
       `deyu`.`classes`.`teacherid`       AS `teacherid_0`,
       `deyu`.`classes`.`majorid`         AS `majorid_0`,
       `deyu`.`classes`.`collegeid`       AS `collegeid_0`,
       `deyu`.`major`.`majorinfo`         AS `majorinfo`,
       `deyu`.`college`.`collegeinfo`     AS `collegeinfo`,
       `deyu`.`teacher`.`teacherinfo`     AS `teacherinfo`,
       `deyu`.`students`.`score`          AS `score`,
       `deyu`.`major`.`collegeid`         AS `collegeid`,
       `deyu`.`major`.`majorid`           AS `majorid`,
       `deyu`.`teacher`.`teacherid`       AS `teacherid`,
       `deyu`.`college`.`collegeid`       AS `collegeid_1`,
       `deyu`.`students`.`s_apartment`    AS `s_apartment`,
       `deyu`.`students`.`s_dormitory`    AS `s_dormitory`,
       `deyu`.`apartment`.`apartmentinfo` AS `apartmentinfo`,
       `deyu`.`dormitory`.`dormitoryinfo` AS `dormitoryinfo`,
       `deyu`.`students`.`openid`         AS `openid`,
       `deyu`.`apartment`.`apartmentid`   AS `apartmentid`
from ((((((`deyu`.`classes` join `deyu`.`major`) join `deyu`.`students`) join `deyu`.`college`) join `deyu`.`teacher`) join `deyu`.`apartment`)
         join `deyu`.`dormitory`)
where ((`deyu`.`students`.`s_class` = `deyu`.`classes`.`classes`) and
       (`deyu`.`classes`.`majorid` = `deyu`.`major`.`majorid`) and
       (`deyu`.`major`.`collegeid` = `deyu`.`college`.`collegeid`) and
       (`deyu`.`classes`.`teacherid` = `deyu`.`teacher`.`teacherid`) and
       (`deyu`.`apartment`.`apartmentid` = `deyu`.`dormitory`.`apartmentid`) and
       (`deyu`.`students`.`s_dormitory` = `deyu`.`dormitory`.`dormitoryid`) and
       (`deyu`.`students`.`s_apartment` = `deyu`.`apartment`.`apartmentid`));

