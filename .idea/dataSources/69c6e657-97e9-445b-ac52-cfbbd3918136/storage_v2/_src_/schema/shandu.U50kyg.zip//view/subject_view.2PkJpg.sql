create view subject_view as
select `shandu`.`subject`.`s_id`        AS `s_id`,
       `shandu`.`subject`.`subjectinfo` AS `subjectinfo`,
       `shandu`.`subject`.`majorid`     AS `majorid`,
       `shandu`.`major`.`majorinfo`     AS `majorinfo`
from (`shandu`.`subject`
         join `shandu`.`major` on ((`shandu`.`subject`.`majorid` = `shandu`.`major`.`majorid`)));

