create view comment_view as
select `shandu`.`user`.`name`         AS `name`,
       `shandu`.`comment`.`commentid` AS `commentid`,
       `shandu`.`comment`.`note_id`   AS `note_id`,
       `shandu`.`comment`.`u_id`      AS `u_id`,
       `shandu`.`comment`.`content`   AS `content`,
       `shandu`.`comment`.`datatime`  AS `datatime`,
       `shandu`.`comment`.`collecnum` AS `collecnum`,
       `shandu`.`comment`.`code`      AS `code`,
       `shandu`.`note`.`userid`       AS `userid`,
       `shandu`.`note`.`title`        AS `title`,
       `shandu`.`note`.`contentinfo`  AS `contentinfo`,
       `shandu`.`user`.`vx_head`      AS `vx_head`
from ((`shandu`.`comment` join `shandu`.`user` on ((`shandu`.`comment`.`u_id` = `shandu`.`user`.`u_id`)))
         join `shandu`.`note` on ((`shandu`.`comment`.`note_id` = `shandu`.`note`.`id`)));

