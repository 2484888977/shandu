create view note_view as
select `shandu`.`user`.`name`           AS `name`,
       `shandu`.`note`.`id`             AS `id`,
       `shandu`.`note`.`majorid`        AS `majorid`,
       `shandu`.`note`.`userid`         AS `userid`,
       `shandu`.`note`.`comnum`         AS `comnum`,
       `shandu`.`note`.`title`          AS `title`,
       `shandu`.`note`.`contentinfo`    AS `contentinfo`,
       `shandu`.`note`.`collecnum`      AS `collecnum`,
       `shandu`.`note`.`collecid`       AS `collecid`,
       `shandu`.`note`.`datatime`       AS `datatime`,
       `shandu`.`major`.`majorinfo`     AS `majorinfo`,
       `shandu`.`note`.`recommendid`    AS `recommendid`,
       `shandu`.`note`.`subjectid`      AS `subjectid`,
       `shandu`.`subject`.`subjectinfo` AS `subjectinfo`,
       `shandu`.`user`.`vx_head`        AS `vx_head`
from (((`shandu`.`user` join `shandu`.`note` on ((`shandu`.`user`.`u_id` = `shandu`.`note`.`userid`))) join `shandu`.`major` on ((`shandu`.`note`.`majorid` = `shandu`.`major`.`majorid`)))
         join `shandu`.`subject` on ((`shandu`.`note`.`subjectid` = `shandu`.`subject`.`s_id`)));

